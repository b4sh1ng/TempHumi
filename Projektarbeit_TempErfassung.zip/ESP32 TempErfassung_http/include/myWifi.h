#include "Arduino.h"



void connectToWifi();
bool wifiIsConnected();
