﻿namespace Statisitsche_Temp_Erfassung.Enums
{
    [Flags]
    enum EnumWeekdays
    {
        Sonntag,
        Montag,
        Dienstag,
        Mittwoch,
        Donnerstag,
        Freitag,
        Samstag,
    }
}
